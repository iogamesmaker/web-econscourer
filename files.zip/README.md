# Drednot.io Economic Data Tracker

Daily economic data tracker for Drednot.io game. Updates automatically every day at 00:30 UTC.

## Features
- Daily data updates
- Interactive visualizations
- Search functionality
- Historical data tracking

## Data Sources
Data is sourced from pub.drednot.io public API endpoints.